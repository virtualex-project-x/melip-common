package com.melip.common.dto.common;

import java.io.Serializable;

/**
 * DTOの基底インタフェースです。
 */
public interface IDto extends Serializable {
}
