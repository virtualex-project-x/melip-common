package com.melip.common.dto.common;

/**
 * DTOの基底インタフェースです。
 */
public interface IDto {
}
